/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryMgmt;

/**
 *
 * @author rfn2257
 */
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DataStore {

    DBManager dbManager;
    Connection conn;
    Statement statement;

    public DataStore() {
        dbManager = new DBManager();
        conn = dbManager.getConnection();
        try {
            statement = conn.createStatement();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }
    //Test Table 
    public static void main(String[] args) {
        DataStore sbs = new DataStore();

        try {
            sbs.statement.addBatch("CREATE  TABLE category  (id  INT,   name   VARCHAR(50),   status   VARCHAR(20)");
            sbs.statement.addBatch("INSERT INTO category VALUES (1, 'Book', 'Active'),\n"
                    + "(2, 'FOOD', 'Active'),\n"
                    + "(3, 'CLOTH', 'Desactive')");
            sbs.statement.executeBatch();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        sbs.closeConnection();
    }

    public void closeConnection() {
        this.dbManager.closeConnections();
    }

}