/*
 * To add new record into database 
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryMgmt;


import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author rfn2257
 */
public class InsertRecord {
    DBManager dbManager;
    Connection conn;
    PreparedStatement statement;

    public InsertRecord() {
        dbManager = new DBManager();
        conn = dbManager.getConnection();

    }

    public void addRecord() {       
        try {
            this.statement = conn.prepareStatement("insert into category values(?,?,?)");
            this.statement.setInt(1,1000);//1 specifies the first parameter in the query
            this.statement.setString(1,"name");
            this.statement.setString(2,"DDD");
            this.statement.executeBatch();
            int i=statement.executeUpdate();
            System.out.println(i+" records inserted");
            
            conn.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
   

