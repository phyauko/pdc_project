/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rfn2257
 */
class Connect {
    public Connect(){
   
        try {
            Connection conn;
            //try {
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/studentDB", "pdc", "pdc");
           // preparedStatement st = conn.preparedStatement("insert into CATEGORY(catID, catName, catStatus) values(?, ?, ?");
            st.setInt(1, 101);
            st.setString(2,"CLOTHS");
            st.setString(2,"Active");
            int a = st.executeUpdate();
            
            if(a>0){
                System.out.println("Row Inserted");
            }
            //} catch (SQLException ex) {
            //   Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
            //}          
        } catch (SQLException ex) {
            Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}