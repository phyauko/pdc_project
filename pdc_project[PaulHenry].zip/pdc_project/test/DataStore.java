

import Test.DBManager;
import DBManagement.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DataStore {

    DBManager dbManager;
    Connection conn;
    Statement statement;

    public DataStore() {
        dbManager = new DBManager();
        conn = dbManager.getConnection();
        try {
            statement = conn.createStatement();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static void main(String[] args) {
        DataStore sbs = new DataStore();

        try {
            sbs.statement.addBatch("CREATE  TABLE CATEGORY  (catID  INT,      catName   VARCHAR(50),  catStatus   VARCHAR(20),)");
            sbs.statement.addBatch("INSERT INTO CATEGORY VALUES (1, 'BOOK', 'Active'),\n"
                    + "(2, 'CLOTH', 'Desactive'),\n"
                    + "(3, 'FOOD', 'Active'");
            sbs.statement.executeBatch();
            sbs.statement.executeUpdate(string);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        sbs.closeConnection();
    }

    public void closeConnection() {
        this.dbManager.closeConnections();
    }

}
